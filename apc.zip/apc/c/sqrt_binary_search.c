#include<stdio.h>
int sq(int n){
int l=0,r=n;
while(l<=r){
    int m=(l+r)/2;
    if(m*m==n)
        return m;
    else if(m*m>n)
        r=m-1;
    else if(m*m<n)
        l=m+1;
}
return r;

}
int main(){
int n;
scanf("%d",&n);
printf("%d",sq(n));
}
