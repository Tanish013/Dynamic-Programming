#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
char c[100];
gets(c);
//scanf("%s",&c);
int l=strlen(c),i=0;
char **a=(char **)malloc(sizeof(char*)*l);
for(int z=0;z<l;z++)
    a[i]=(char*)malloc(sizeof(char*)*50);
char *tok=strtok(c," ");
while(tok!=NULL){
    a[i++]=tok;
 tok=strtok(NULL," ");
}
for(int z=i-1;z>=0;z--)
    printf("%s ",a[z]);
}
