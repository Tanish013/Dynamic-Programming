#include<stdio.h>
int main(){
int a[11]={1,1,2,2,3,4,4,4,5,5,5};
int l=0,r=10,el=4;
while(l<r){
    int m=(l+r)/2;
    if(a[m]>el)
        r=m;
    else
        l=m+1;
}
printf("%d",a[r]);
}
