#include<stdio.h>
int cmp(const void *a,const void *b){
return *(int*)a-*(int*)b;
}
int coin(int *arr,int m,int n){
    qsort(arr,m,sizeof(int),cmp);
long table[m][n+1];
for(int i=0;i<m;i++)
    table[i][0]=1;
for(int i=1;i<=n;i++){
    if(i%arr[0]==0){
        table[0][i]=1;
    }
    else{
        table[0][i]=0;
    }
}
    int i,j;
for(i=1;i<m;i++){
for(j=1;j<=n;j++){
 if(j<arr[i]){
    table[i][j]=table[i-1][j];
 }
 else{
    table[i][j]=table[i-1][j]+table[i][j-arr[i]];
 }
}
}
/*for(int i=0;i<m;i++){
    for(int j=0;j<=n;j++){
        printf("%d ",table[i][j]);
    }
    printf("\n");
}*/
//int res=table[arr[m-1]][n];
return table[m-1][n];
}
int main(){
int size,n;
scanf("%d%d",&n,&size);
int arr[size];
for(int i=0;i<size;i++){
    scanf("%d",&arr[i]);
}
printf("ways=%d",coin(arr,size,n));
}
