#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void ins(struct node **h,int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*h;
n->data=d;
n->next=NULL;
if(*h==NULL){
    *h=n;
}
else{
    while(curr->next!=NULL)
        curr=curr->next;

curr->next=n;
}
}
struct node* rev(struct node* head)
{
struct node *first=head;
struct node *second=NULL;
if(first)
    second=first->next;
if(second==NULL)
    return head;
else{
struct node *h=rev(second);
first->next=second->next;
second->next=first;
return h;}
}
void pri(struct node *n){
while(n!=NULL){
    printf("%d\n",n->data);
    n=n->next;
}
}
int main(){
int n;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    int d;
    scanf("%d",&d);
    ins(&head,d);
}
head=rev(head);
pri(head);
}
