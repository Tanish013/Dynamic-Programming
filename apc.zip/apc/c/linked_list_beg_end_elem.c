#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*h;
n->data=d;
n->next=NULL;
if(*h==NULL)
    *h=n;
else{
    while(curr->next!=NULL)
        curr=curr->next;
    curr->next=n;
}
}
void rem(struct node *h){
    struct node *curr=h;
    while(curr&&curr->next){
            if(curr->data==curr->next->data){
                curr->next=curr->next->next;
            }
            else
                curr=curr->next;
    }
}
void pri(struct node *h){
while(h!=NULL){
printf("%d ",h->data);
h=h->next;
}
}
int main(){
int n;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    int d;
    scanf("%d",&d);
    push(&head,d);
}
rem(head);
pri(head);
}
