#include<stdio.h>
#include<stdlib.h>
int main(){
int n;
scanf("%d",&n);
// SIR 's LOGIC

int x=(n>>1)&(0X55555555);
int y=(n<<1)&(0XAAAAAAAA);
printf("%d",x|y);
/*for(int i=0;i<32;i=i+2){
    int m=n&(1<<(i-1));
    int o=n&(1<<(i-2));
    n=n&(~m);
    n=n&(~o);
}*/
//printf("%d",n);
}
