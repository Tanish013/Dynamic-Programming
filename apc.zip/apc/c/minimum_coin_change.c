#include<stdio.h>
int cmp(const void *a,const void *b){
return *(int*)a-*(int*)b;
}
void mini(int *arr,int n,int sum){
int table[n+1][sum+1];
qsort(arr,n,sizeof(int),cmp);
for(int i=0;i<=n;i++)
table[i][0]=0;
for(int i=1;i<=sum;i++)
    table[0][i]=0;
for(int i=1;i<=n;i++){
    for(int j=1;j<=sum;j++){
        if(j<arr[i-1]){
            table[i][j]=table[i-1][j];
        }
        else{
            if(j%arr[i-1]==0){
                table[i][j]=j/arr[i-1];
            }
            else{
                if(table[i][j-arr[i-1]]!=0){
                    table[i][j]=table[i][j-arr[i-1]]+1;
                }
                else{
                    table[i][j]=table[i-1][j];
                }
            }
        }
    }
}
for(int i=0;i<=n;i++){
    for(int j=0;j<=sum;j++){
        printf("%d ",table[i][j]);
    }
    printf("\n");
}
int min=table[n][sum],count=0;
for(int i=n;i>=0;i--){
    if(table[i][sum]<=min&&table[i][sum]>0){
        min=table[i][sum];
        count++;
    }
}
printf("MINIMUM COINS=%d\nWAYS=%d",min,count);
}
int main(){
int n;
scanf("%d",&n);
int a[n];
for(int i=0;i<n;i++){
    scanf("%d",&a[i]);
}
int sum;
scanf("%d",&sum);
mini(a,n,sum);
}
