#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
struct node *prev;
}*front,*rear;
void push(int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=d;
n->next=NULL;
n->prev=NULL;
if(front==NULL){
    front=n;
    rear=n;
}
else{
rear->next=n;
n->prev=rear;
rear=n;
}
}
void pri(){
while(rear!=NULL){
    printf("%d ",rear->data);
    rear=rear->prev;

}
}
int main(){
int n;
scanf("%d",&n);
front=NULL;
rear=NULL;
for(int i=0;i<n;i++){
    int d;
    scanf("%d",&d);
    push(d);
}
pri();

}
