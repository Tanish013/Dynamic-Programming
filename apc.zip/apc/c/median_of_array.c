#include<stdio.h>
int main(){
    int n,m;
    scanf("%d%d",&n,&m);
int a[n],b[m];
for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
for(int i=0;i<m;i++)
    scanf("%d",&b[i]);
a[n]=2147483647,b[m]=2147483647,a[-1]=-2147483647,b[-1]=-2147483647;
int i,j,s=n+m;
i=n/2;
if((s)%2!=0){
        j=((s+1)/2)-i;
        }
else if(s%2==0){
    j=(s/2)-i;
}
while(i<=n&&j<=m){
        if(a[i-1]<b[j]&&b[j-1]<a[i]){
            if(s%2!=0){
                printf("%d\n",(a[i-1]>b[j-1]?a[i-1]:b[j-1]));
                break;}
            else if(s%2==0){
                int ma=(a[i-1]>b[j-1]?a[i-1]:b[j-1]);
                int mi=(a[i]<b[j]?a[i]:b[j]);
                printf("%.1f",(float)(mi+ma)/2);
                break;
                }
        }
        else if(a[i-1]>b[j]&&b[j-1]<a[i]){
            j++;
            i--;
        }
        else if(a[i-1]<b[j]&&b[j-1]>a[i]){
            i++;
            j--;
        }
}
}
