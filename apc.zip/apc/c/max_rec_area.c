#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,int val){
struct node *n=(struct node*)malloc(sizeof(struct node));
n->data=val;
n->next=*h;
*h=n;
}
int peek(struct node *head){
return head->data;
}
void pop(struct node **h){
struct node *curr=*h;
*h=curr->next;
free(curr);
}
int ar(int n,int a[n]){
struct node *head=NULL;
int max=-1;
for(int i=0;i<n;i++){
if(head==NULL||a[i]>=a[peek(head)]){
    push(&head,i);
}
else{
    while(head!=NULL&&a[i]<a[peek(head)]){
          int x=peek(head);
          pop(&head);
          int dist=(head==NULL ? i : i-(peek(head))-1);
          int ar=a[x]*dist;
          if(ar>max)
            max=ar;
          }
          push(&head,i);
}
}
while(head!=NULL){
    int x=peek(head);
          pop(&head);
          int dist=(head==NULL?n:n-peek(head)-1);
          int ar=a[x]*dist;
          if(ar>max)
            max=ar;
          }
return max;
}
int main(){
int n[]={2,1,5,6,2,3};
int len=sizeof(n)/sizeof(n[0]);
printf("Max area=%d",ar(len,n));
}
