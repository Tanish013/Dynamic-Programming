#include<stdio.h>
#include<stdlib.h>
struct node{
char data;
struct node *next;
};
void push(struct node **h,char c){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=c;
n->next=*h;
*h=n;
}
int prec(char c){
if(c=='+'||c=='-')
    return 1;
else if(c=='*'||c=='/')
    return 2;
else if(c=='^')
    return 3;
else
    return -1;
}
int main(){
char c[100]="a+b*c+d";
int len=sizeof(c)/sizeof(c[0]),i,j=0;
char res[len +1];
struct node *head=(struct node *)malloc(sizeof(struct node));
head->data='N';
head->next=NULL;
for(i=0;c[i]!='\0';i++){
    if((c[i]>=65&&c[i]<=90)||(c[i]>=97&&c[i]<=122)){
     res[j++]=c[i];
    }
    else if(c[i]=='('){
                push(&head,c[i]);
            }
    else if(c[i]=='+'||c[i]=='-'||c[i]=='*'||c[i]=='/'||c[i]=='^'){
            int a=prec(c[i]);
            int b=prec(head->data);
            if(b<=a){
                push(&head,c[i]);
            }
            else{
                while(head->next){
                    res[j++]=head->data;
                    head=head->next;
                }
                push(&head,c[i]);
            }
    }
    else if(c[i]==')'){
        while(head->data!='('){
                res[j++]=head->data;
                head=head->next;
              }
    }
}
if(head)
{
    while(head->next)
    {
        res[j++]=head->data;
        head=head->next;
    }
}
for(int z=0;z<j;z++)
    printf("%c",res[z]);
return 0;
}
