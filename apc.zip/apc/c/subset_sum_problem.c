#include<stdio.h>
//recurrisive solution
/*int subset(int *arr,int n,int sum){
if(sum==0)
    return 1;
if(n==0&&sum>0)
    return 0;
if(arr[n-1]>sum)
    return subset(arr,n-1,sum);
else
    return subset(arr,n-1,sum-arr[n-1])||subset(arr,n-1,sum);
}*/
// Dynamic programming solution
int cmp(const void *a,const void *b){
return *(int*)a-*(int*)b;
}
int subset(int *arr,int n,int sum){
qsort(arr,n,sizeof(int),cmp);
int table[n+1][sum+1];
for(int i=0;i<=n;i++){
    table[i][0]=1;
}
for(int i=1;i<=sum;i++){
    table[0][i]=0;
}
for(int i=1;i<=n;i++){
    for(int j=1;j<=sum;j++){
        if(j<arr[i-1]){
            table[i][j]=table[i-1][j];
        }
        if(j>=arr[i-1]){
            table[i][j]=table[i-1][j]||table[i-1][j-arr[i-1]];
        }
    }
}
for(int i=0;i<=n;i++){
    for(int j=0;j<=sum;j++){
        printf("%d ",table[i][j]);
    }
    printf("\n");
}
return table[n][sum];
}
int main(){
int n;
scanf("%d",&n);
int a[n];
for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
int sum;
scanf("%d",&sum);
if(subset(a,n,sum)){
    printf("FOUND SUBSET EQUAL TO SUM");
}
else
    printf("NOT FOUND");
}
