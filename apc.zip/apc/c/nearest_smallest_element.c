#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,int val){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=val;
n->next=*h;
*h=n;
}
int  peek(struct node *h){
    return h->data;
}
void pop(struct node **h){
struct node *curr=*h;
*h=curr->next;
free(curr);
}
void small_ele(int n,int a[n]){
    int res[n];
struct node *head=NULL;
for(int i=0;i<n;i++)
    res[i]=-1;
for(int i=n-1;i>=0;i--){
    if(head==NULL||a[i]>=a[peek(head)]){
        push(&head,i);
    }
    else{
        while(head!=NULL&&a[i]<a[peek(head)]){
              int x=peek(head);
              res[x]=a[i];
              pop(&head);
              }
              push(&head,i);
    }
}
while(head->next!=NULL&&a[peek(head)]>a[peek(head->next)]&&peek(head)>peek(head->next)){
    int x=peek(head);
    pop(&head);
    res[x]=a[peek(head)];
}
for(int i=0;i<n;i++)
    printf("%d ",res[i]);
}
int main(){
int a[]={1};
int len=sizeof(a)/sizeof(a[0]);
small_ele(len,a);
}
