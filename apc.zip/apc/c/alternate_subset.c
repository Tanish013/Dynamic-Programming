#include <stdio.h>

int main() {
	int t;
	scanf("%d",&t);
	for(int z=0;z<t;z++){
	    int n;
	    scanf("%d",&n);
	    long a[n],fi[n];
	    for(int i=0;i<n;i++)
	    scanf("%ld",&a[i]);
	    fi[n-1]=1;
	    for(int i=n-2;i>=0;i--){
	        if(a[i]*a[i+1]<0)
	        fi[i]=fi[i+1]+1;
	        else
	        fi[i]=1;
	}
	for(int i=0;i<n;i++)
	printf("%d ",fi[i]);
	printf("\n");
	}
	return 0;
}

