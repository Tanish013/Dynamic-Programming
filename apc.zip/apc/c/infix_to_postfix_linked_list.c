#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,char c){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=c;
n->next=*h;
*h=n;
}
int prec(char c){
if(c=='+'||c=='-')
    return 1;
else if(c=='*'||c=='/')
    return 2;
else if(c=='^')
    return 3;
else
    return -1;
}
void pri(struct node *h){
while(h!=NULL){
    printf("%c\n",h->data);
    h=h->next;
}
}
char peek(struct node *h){
if(h==NULL)
    return '@';
else{
    return h->data;
}
}
int main(){
char c[]="a+b*c-d/e*h";
int len=sizeof(c)/sizeof(c[0]),i,j=0;
char res[len];
struct node *head=NULL;
for(i=0;i<len;i++){
    if((c[i]>=65&&c[i]<=90)||(c[i]>=97&&c[i]<=122)){
     res[j]=c[i];
     j++;
    }
    else if(c[i]=='('){
                push(&head,c[i]);
            }
    else if(c[i]=='+'||c[i]=='-'||c[i]=='*'||c[i]=='/'||c[i]=='^'){
        //printf("%c\n",c[i]);
            if(head==NULL){
                   // printf("%c\n",c[i]);
                push(&head,c[i]);
            }
            else
            {
            int a=prec(c[i]);
            int b=prec(head->data);
            //printf("%d %d\n",a,b);
            if(b<a){
                push(&head,c[i]);
            }
            else{
                   //pri();
                   char p=peek(head);
                //printf("%c\n",p);
                while(prec(p)>=prec(c[i])&&head!=NULL){
                    //printf("%c\n",head->data);
                    res[j]=head->data;
                    head=head->next;
                    p=peek(head);
                    j++;
                }
                //printf("%c\n",head->data);
                push(&head,c[i]);
               // pri(head);
            }
            }
    }
    else if(c[i]==')'){
        while(head->data!='('){
                res[j]=head->data;
                j++;
                head=head->next;
              }
head=head->next;
    }
}

while(head!=NULL){
    res[j]=head->data;
    head=head->next;
    j++;
}
for(int z=0;z<j;z++){
    printf("%c",res[z]);
}
}
