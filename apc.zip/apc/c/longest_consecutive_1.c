#include<stdio.h>
int main(){
int n=10;
int ar[10]={1,1,0,1,1,0,0,1,1,1},k=1,l=0,max_len=0,c=0,b_l=0,b_r=0;
for(int i=0;i<n;i++){
    if(ar[i]==0)
        c++;
    while(c>k){
        if(ar[l]==0)
            c--;
        l++;
    }
    if(max_len<i-l+1){
        max_len=i-l+1;
        b_l=l;
        b_r=i;
    }
}
for(int i=b_l;i<=b_r;i++)
    printf("%d\n",i);
printf("maximum dist = %d",max_len);
}
