#include<stdio.h>
int main(){
int n=5,a=1;
while(a<=n){
    n=n^a;
    a=a<<1;
}
printf("%d",n);
}
