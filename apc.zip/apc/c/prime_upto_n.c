#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int sum(int n){
    int sum=0;
    while(n!=0){
        int i=n%10;
        sum+=i;
        n=n/10;
    }
    return sum;
}
int main(){
int a,b,k;
scanf("%d%d%d",&a,&b,&k);
int *arr=(int*)calloc(b+1,sizeof(int));
for(int i=2;i*i<=b;i++){
    if(!arr[i]){
        for(int j=i*i;j<=b;j=j+i){
            arr[j]=1;
        }
    }
}
int count=0;
for(int i=a;i<=b;i++){
    if(i%k==0){
        if(arr[sum(i)]==0){
            count++;
        }
    }
}
printf("%d",count);
}
