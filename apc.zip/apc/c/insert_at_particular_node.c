#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **head,int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*head;
n->data=d;
n->next=NULL;
if(*head==NULL)
    *head=n;
else{
    while(curr->next!=NULL)
        curr=curr->next;
    curr->next=n;
}
}
void ins(struct node *h,int pos,int v){
struct node *curr=h;
struct node *n=(struct node*)malloc(sizeof(struct node));
n->data=v;
n->next=NULL;
int i=0;
while(curr!=NULL&&i<pos-1){
    curr=curr->next;
    i++;
}
n->next=curr->next;
curr->next=n;
}
void pri(struct node *h){
while(h!=NULL){
printf("%d\n",h->data);
h=h->next;
}
}
int main(){
int n;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    int d;
    scanf("%d",&d);
    push(&head,d);
}
int pos,val;
printf("Enter the position at which you want to insert and what you want to insert\n");
scanf("%d%d",&pos,&val);
ins(head,pos,val);
pri(head);
}
