#include<stdio.h>
int power(int n,int m){
if(m==0)
    return 1;
int num1=power(n,m/2);
if(m%2==0){
    return num1*num1;
}
else
    return n*num1*num1;
}
int main(){
int n;
int m;
scanf("%d%d",&n,&m);
printf("%d",power(n,m));
}
