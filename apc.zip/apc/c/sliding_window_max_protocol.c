#include<stdio.h>
#include<stdlib.h>
struct node {
int data;
struct node *next;
struct node *prev;
}*front,*rear;
void push(int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=d;
n->next=NULL;
n->prev=NULL;
if(rear==NULL){
    front=n;
    rear=n;
}
else{
n->prev=rear;
rear->next=n;
rear=n;
}
}
void pop(){
    if(front==NULL){
    front=NULL;
    rear=NULL;
    }
    else{
        struct node *curr=front;
        front=front->next;
    if(front==NULL)
        rear=NULL;
    else
        front->prev=NULL;
    free(curr);
    }
}
void po(){
    if(rear==NULL){
front=NULL;
rear=NULL;
    }
    else{
        struct node *curr=rear;
        rear=rear->prev;
    if(rear==NULL)
        front=NULL;
    else
        rear->next=NULL;
    free(curr);
    }
}
void fun(int n,int a[n],int k){
int i;
for(i=0;i<k;i++){
        while(front!=NULL&&rear!=NULL&&a[i]>=a[rear->data]){
            po();
        }
    push(i);
}
for(;i<n;++i){
printf("%d ",a[front->data]);
while(front!=NULL&&rear!=NULL&&front->data<=i-k){
    pop();
}
while(rear!=NULL&&front!=NULL&&a[i]>=a[rear->data]){
    po();
    }
    push(i);
}
printf("%d ",a[front->data]);
}
int main(){
    front=NULL;
    rear=NULL;
int a[]={ 718, 622, 531, 279, 442, 893, 282, 875, 252, 70, 402, 663, 22, 69, 611, 412, 302, 840, 589, 668, 346, 983, 227, 23, 703, 818, 100, 943, 728, 305, 72, 772, 35, 721, 550, 12, 405, 454, 902, 978, 579 };
int len=sizeof(a)/sizeof(a[0]);
int k=9;
fun(len,a,k);
}
