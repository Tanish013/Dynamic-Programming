#include<stdio.h>
int min(int a,int b){
if(a<b)
    return a;
else
    return b;
}
int bionomial(int n,int k){
int c[n+1][k+1];
for(int i=0;i<=n;i++){
    int q=min(i,k);
    for(int j=0;j<=q;j++){
        if(j==0||j==i){
            c[i][j]=1;
        }
        else{
            c[i][j]=c[i-1][j-1]+c[i-1][j];
        }
    }
}
return c[n][k];
}
int main(){
int n,k;
scanf("%d%d",&n,&k);
if(k>n){
    printf("0 is bionomial coefficient as k is greater n");
}
else{
    printf("%d",bionomial(n,k));
}
}
