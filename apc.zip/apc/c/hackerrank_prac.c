#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
char* encode(char* input) {
char c[64]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','+','/','0','1','2','3','4','5','6','7','8','9',};
int len=strlen(input),index=0,i;
char *res=(char*)malloc(sizeof(char)*((len/3)*4+5));
for(i=0;i<len-(len%3);i=i+3){
    res[index]=c[(input[i]&0XFC)>>2];
    index++;
    res[index]=c[((input[i]&0X03)<<4)|((input[i+1]&0XF0)>>4)];
    index++;
    res[index]=c[((input[i+1]&0X0F)<<2)|((input[i+2]&0XC0)>>6)];
    index++;
    res[index]=c[(input[i+2]&0X3F)];
    index++;
}
if(len%3==2){
    res[index]=c[(input[i]&0XFC)>>2];
    index++;
    res[index]=c[((input[i]&0X03)<<4)|((input[i+1]&0XF0)>>4)];
    index++;
    res[index]=c[((input[i+1]&0X0F)<<2)|((input[i+2]&0XC0)>>6)];
    index++;
res[index++]='=';
}
else if(len%3==1){
    res[index]=c[(input[i]&0XFC)>>2];
    index++;
    res[index]=c[((input[i]&0X03)<<4)|((input[i+1]&0XF0)>>4)];
    index++;
    res[index]='=';
    index++;
    res[index++]='=';
}
return res;
}
int main() {
    char input[51200];
    scanf("%s",&input);
    printf("%s\n",encode(input));
    return 0;
}
