#include<stdio.h>
void print1(int x,int a[x]){
int i=1,j=0,flag=1;
for(i=1;i<x;i++){
    if(a[i]==a[j]&&flag==1){
        flag=0;
        j++;
        a[j]=a[i];
    }
    else if(a[i]!=a[j]&&flag==0){
        flag=1;
        j++;
        a[j]=a[i];
    }
    else if(a[i]!=a[j]&&flag==1){
        j++;
        a[j]=a[i];
    }
}
for(int q=0;q<=j;q++)
    printf("%d ",a[q]);

}

int main(){
int n;
scanf("%d",&n);
int a[n];
for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
print1(n,a);
}
