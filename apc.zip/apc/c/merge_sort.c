#include<stdio.h>
#include<stdlib.h>
static int c=0;
void merge(int *a,int l,int m,int r){
int n1=m-l+1,n2=r-m;
int L[n1],R[n2];
int i=0,j=0,k=l;
for(i=0;i<n1;i++){
    L[i]=a[l+i];
    //printf("%d ",L[i]);
}
for(i=0;i<n2;i++){
    R[i]=a[m+1+i];
    //printf("%d ",R[i]);
}
//printf("\n");

/*for(i=0;i<n1;i++)
    for(j=m+i;j<m+n2;j++)
{
    if(a[i]>a[j])
        c++;

}*/
i=0;
while(i<n1&&j<n2){
    if(L[i]<=R[j]){
        a[k]=L[i];
        i++;

    }
    else{
        a[k]=R[j];
        j++;
    }
    k++;
}
while(i<n1){
    a[k]=L[i];
    k++;
    i++;
}
while(j<n2){
    a[k]=R[j];
    k++;
    j++;
}
}
void mergesort(int *a,int l,int r){
if(l<r){
int mid=(l+r)/2;
mergesort(a,l,mid);
mergesort(a,mid+1,r);
merge(a,l,mid,r);

/*for (int i=0; i<r; i++)
        printf("%d ", a[i]);
    printf("\n");*/
}
}
int main(){
int a[]={5,6,2,3,1};
mergesort(a,0,5);
for(int i=0;i<5;i++){
    printf("%d ",a[i]);
}
printf("\ncount=%d ",c);
}
