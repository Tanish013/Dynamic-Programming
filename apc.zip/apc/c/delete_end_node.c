#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*h;
n->data=d;
n->next=NULL;
if(*h==NULL){
    *h=n;
}
else{
    while(curr->next!=NULL)
        curr=curr->next;

curr->next=n;
}
}
void del(struct node **h){
if(*h==NULL)
    return;
else{
    struct node *curr=*h;
    struct node *temp=NULL;
    while(curr->next->next!=NULL){
        curr=curr->next;
    }
    temp=curr->next;
    curr->next=NULL;
    free(temp);
    temp=NULL;
}
}
void pri(struct node *h){
while(h!=NULL){
    printf("%d\n",h->data);
    h=h->next;
}
}
int main(){
printf("Enter the size of linked list ");
int n,val;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    printf("Enter the value to be inserted ");
scanf("%d",&val);
push(&head,val);
}
del(&head);
pri(head);
}
