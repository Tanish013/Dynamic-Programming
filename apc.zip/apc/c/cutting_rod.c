#include<stdio.h>
int max(int a,int b){
if(a>=b)
    return a;
else
    return b;
}
int pri(int *price,int n){
int table[n+1][n+1];
for(int i=0;i<=n;i++)
    table[i][0]=0;
for(int i=1;i<=n;i++)
    table[0][i]=0;
    int max_value=-1;
for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){
        if(j<i){
            table[i][j]=table[i-1][j];
        }
        else{
        table[i][j]=max(table[i-1][j],(table[i][j-i]+price[i-1]));
        }
        if(max_value<table[i][j]){
            max_value=table[i][j];
        }
    }
}
/*for(int i=0;i<=n;i++){
    for(int j=0;j<=n;j++){
        printf("%d ",table[i][j]);
    }
    printf("\n");
}*/
return max_value;
}
int main(){
int n;
scanf("%d",&n);
int price[n];//={3,5,8,9,10,17,17,20};
for(int i=0;i<n;i++){
    scanf("%d",&price[i]);
}
printf("%d",pri(price,n));
}
