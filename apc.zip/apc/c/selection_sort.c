#include<stdio.h>
void sort(int n,int a[n]){
int i,j;
for(i=0;i<n;i++){
    int temp=i;
    for(j=i+1;j<n;j++){
        if(a[j]<a[temp])
            temp=j;
    }
    if(a[i]!=a[temp]){
        int t=a[i];
        a[i]=a[temp];
        a[temp]=t;
    }
}

}
int main(){
int ar[]={5,4,3,2,1};
sort(5,ar);
for(int i=0;i<5;i++){
    printf("%d ",ar[i]);
}
}
