    #include<stdio.h>
#include<stdlib.h>
int main(){
int count =0,c=0;
int n;
scanf("%d",&n);
while(n!=0){
    if(n&1){
        c++;
        if(c>count)
            count=c;
    }
    else
        c=0;
n=n>>1;
}
printf("%d",count);
}
