#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,char c){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=c;
n->next=*h;
*h=n;
}
char peek(struct node **h){
    struct node *curr=*h;
    char c=curr->data;
    return c;
}
void pop(struct node **h){
struct node *curr=*h;
*h=curr->next;
free(curr);
}
int balanced(int len,char c[len]){
struct node *h=NULL;
int flag=0;
for(int i=0;i<len;i++){
    if(c[i]=='('||c[i]=='{'||c[i]=='['){
        push(&h,c[i]);
       }
    else if((c[i]==')'||c[i]=='}'||c[i]==']')&&h==NULL){
            flag==1;
        return 0;
    }
    else if(c[i]==')'&&peek(&h)=='('){
        pop(&h);
    }
    else if(c[i]=='}'&&peek(&h)=='{'){
        pop(&h);
    }
    else if(c[i]==']'&&peek(&h)=='['){
        pop(&h);
    }
}
if(flag==0&&h==NULL)
return 1;
else
    return 0;
}
int main(){
char c[100];
gets(c);
int l=sizeof(c)/sizeof(c[0]);
if(balanced(l,c)){
    printf("Balanced parentheses");
}
else{
    printf("Not balanced");
}
}
