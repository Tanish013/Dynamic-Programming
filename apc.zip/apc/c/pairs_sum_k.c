
#include <stdio.h>
#include<stdlib.h>
int cmp(const void *a,const void *b){
  return *(int*)a-*(int*)b;
}
int search(int *a,int l,int r,int f){
  while(l<r){
    int mid=(l+r)/2;
    if(a[mid]==f){
      return mid;
    }
    else if(a[mid]>f){
      r=mid;
    }
    else if(a[mid]<f){
      l=mid+1;
    }
  }
  return -1;
}
int getPairsCount(int arr[], int n, int sum)
{
  qsort(arr,n,sizeof(int),cmp);
  int count =0;
  for(int i=0;i<n-1;i++){
    int temp=arr[i];
    int j=1;
    int se=search(arr,i+j,n,sum-temp);
    int se1=-1;
    while(se!=se1){
      count++;
      j++;
      se1=search(arr,i+j,n,sum-temp);
      if(se1==-1)
        break;
    }
  }
  return count;
}
int main()
{
    int arr[]={1,1,1,1};
    printf("%d",getPairsCount(arr,4,2));
    return 0;
}

