#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void ins(struct node **h,int val){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*h;
n->data=val;
n->next=NULL;
if(*h==NULL){
    *h=n;
}
else{
    while(curr->next!=NULL)
        curr=curr->next;

curr->next=n;
}
}
void pri(struct node *h){
while(h!=NULL){
    printf("%d\n",h->data);
    h=h->next;
}
}
int main(){
printf("Enter the size of linked list ");
int n,val;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    printf("Enter the value to be inserted ");
scanf("%d",&val);
ins(&head,val);
}
pri(head);

}
