#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void ins(struct node **h,int val){
struct node *n=(struct node *)malloc(sizeof(struct node));
n->data=val;
n->next=*h;
*h=n;
}
void pri(struct node *h){
while(h!=NULL){
    printf("%d\n",h->data);
    h=h->next;
}
}
int main(){
printf("Enter the size of linked list ");
int n;
scanf("%d",&n);
struct Node* head = NULL;
for(int i=0;i<n;i++){
int val;
printf("Enter the value to be inserted ");
scanf("%d",&val);
ins(&head,val);
}
pri(head);
return 0;
}
