#include<iostream>
#include<stdlib.h>
using namespace std;
int main(){
    //long long t;
    //cin>>t;
    //while(t--){
        long long n;
cin>>n;
long long a[n+1];
for(int i=0;i<n;i++)
    cin>>a[i];
    long long i,max1[10001],max2[10001],min1[10001],min2[10001],ma=-21365458;
for(i=0;i<n;i++){
    max1[i]=max2[i]=min1[i]=min2[i]=a[i];
}
for(i=1;i<n;i++){
    if(max1[i-1]>0)
    max1[i]+=+max1[i-1];
}
for(i=n-2;i>=0;i--){
    if(max2[i+1]>0)
    max2[i]+=max2[i+1];
}
for(i=1;i<n;i++){
    if(min1[i-1]<0)
    min1[i]+=min1[i-1];
}
for(i=n-2;i>=0;i--){
    if(min2[i+1]<0)
    min2[i]+=min2[i+1];
}
for(i=0;i<n-1;i++){
        if(abs(max1[i]-min2[i+1])>ma){
            ma=abs(max1[i]-min2[i+1]);
    }
}
for(i=0;i<n-1;i++){
        if(abs(min1[i]-max2[i+1])>ma){
            ma=abs(min1[i]-max2[i+1]);
    }
}
for(i=0;i<n;i++){
    cout<<min2[i]<<" ";
}
cout<<endl;
cout<<ma<<endl;
    }
//}
