#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *next;
};
void push(struct node **h,int d){
struct node *n=(struct node *)malloc(sizeof(struct node));
struct node* curr=*h;
n->data=d;
n->next=NULL;
if(*h==NULL)
    *h=n;
else{
    while(curr->next!=NULL)
        curr=curr->next;
    curr->next=n;
}
}
struct node *rev(struct node *h,int k){
    struct node *curr=h;
    struct node *next=curr->next;
    struct node *prev=NULL;
    int i=0;
    while(curr!=NULL&&i<k){
        next=curr->next;
    curr->next=prev;
    prev=curr;
    curr=next;
    i++;
    }
    if(next!=NULL)
    h->next=rev(next,k);
    return prev;
}
void pri(struct node *h){
while(h!=NULL){
    printf("%d ",h->data);
    h=h->next;
}
}
int main(){
int n;
scanf("%d",&n);
struct node *head=NULL;
for(int i=0;i<n;i++){
    int d;
    scanf("%d",&d);
    push(&head,d);
}
int k;
scanf("%d",&k);
head=rev(head,k);
pri(head);
}
