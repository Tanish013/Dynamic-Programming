#include<stdio.h>
int hcf(int n,int m){
if(m==0)
    return n;
return hcf(m,n%m);

}
int main(){
int n,m;
scanf("%d%d",&n,&m);
printf("%d",hcf(n,m));
}
