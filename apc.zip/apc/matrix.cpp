#include<bits/stdc++.h>
using namespace std;
int fi(vector<vector<char>> a,int sr,int sc,int ma,int k){
    int m=0;
    for(int i=0+sr;i<k;i++){
        for(int j=0+sc;j<k;j++){
            if(a[i][j]=='*')
            m++;
        }
    }
    return (m>=ma?m:ma);
}
int main(){
int n=4,m=4,k=3;
vector<vector<char>> vec;
vec.push_back({'*','.','*','.'});
vec.push_back({'*','*','.','.'});
vec.push_back({'*','.','.','*'});
vec.push_back({'*','.','.','*'});

		int ma=0;
		for(int i=0;i<=n-k;i++){
		for(int j=0;j<=m-k;j++){
		    ma=fi(vec,i,j,ma,k);
		    //cout<<ma<<" ";
		}
		}
		//cout<<endl;
		cout<<ma;
}
