#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
struct tree{
int data;
struct tree *left;
struct tree *right;
};
struct stree{
int di;
struct tree *node;
struct stree *nxt;
};
void push(struct stree **h,struct tree *r,int dist){
struct stree *n=(struct stree*)malloc(sizeof(struct stree));
n->di=dist;
n->node=r;
n->nxt=NULL;
if(*h==NULL){
    *h=n;
}
else{
    struct stree *curr=*h;
    while(curr->nxt!=NULL){
        curr=curr->nxt;
    }
    curr->nxt=n;

}
}
struct tree *pop(struct stree **h){
struct stree *curr=*h;
*h=curr->nxt;
return curr->node;
}
struct map{
int da;
int key;
struct map *left;
struct map *right;
struct map *next;
};
struct map  *mpush(struct map *m,int dist,int val){
    struct map* ma=(struct map*)malloc(sizeof(struct map));
    ma->da=dist;
    ma->key=val;
    ma->right=NULL;
    ma->left=NULL;
    ma->next=NULL;
    if(m==NULL){
    return ma;
}
else if(dist<m->da){
    m->left=mpush(m->left,dist,val);
}
else if(dist>m->da){
    m->right=mpush(m->right,dist,val);
}
else if(dist==m->da){
        struct map *curr=m;
        while(curr->next){
            curr=curr->next;
        }
        curr->next=ma;
}
return m;
}
void print(struct map *node){
if(node==NULL)
    return 0;
print(node->left);
struct map *curr=node;
while(curr!=NULL){
    printf("%d ",curr->key);
    curr=curr->next;
}
print(node->right);
//printf("Hello");
}
void verticalOrder(struct tree *root){
struct stree *queue=NULL;
int dist=0,tdist;
struct map *m=NULL;
push(&queue,root,dist);
while(queue!=NULL){
    tdist=queue->di;
    root=pop(&queue);
    m=mpush(m,tdist,root->data);
    if(root->left)
        push(&queue,root->left,tdist-1);
    if(root->right)
        push(&queue,root->right,tdist+1);
break;
}
print(root);
}
struct tree* newNode(int d){
struct tree *n=(struct tree *)malloc(sizeof(struct tree));
n->data=d;
n->left=NULL;
n->right=NULL;
return n;
}
int main(){
struct tree *root = newNode(1);
    root->left = newNode(2);
    root->right = newNode(3);
    root->left->left = newNode(4);
    root->left->right = newNode(5);
    root->right->left = newNode(6);
    root->right->right = newNode(7);
    root->right->left->right = newNode(8);
    root->right->right->right = newNode(9);
    verticalOrder(root);
}
