#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node* left;
    struct node* right;
};

int max_height(struct node *root){
if(root==NULL){
    return -1; //for maximum height return 0;for height without including root node return-1;
}
else{
    int lDepth=max_height(root->left);
    int rDepth=max_height(root->right);
    if(lDepth>rDepth)
        return lDepth+1;
    else
        return rDepth+1;
}
}
struct node* newNode(int data)
{
    struct node* node = (struct node*)
                                malloc(sizeof(struct node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;

    return(node);
}
int main(){
struct node *root = newNode(1);

    root->left = newNode(2);
    root->right = newNode(3);
    root->left->left = newNode(4);
    root->left->right = newNode(5);
printf("%d ",max_height(root));
}
