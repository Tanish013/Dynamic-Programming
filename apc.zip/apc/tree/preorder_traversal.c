#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

struct node {

    int data;
    struct node *left;
    struct node *right;

};
struct tnode{
struct node *t;
struct tnode *next;
};
struct node* insert(struct node *root,int d){
if(root==NULL){
    struct node *node=(struct node*)malloc(sizeof(struct node));
    node->data=d;
    node->left=NULL;
    node->right=NULL;
    return node;
}
else if(d<=root->data){
    root->left=insert(root->left,d);
}
else if(d>root->data){
    root->right=insert(root->right,d);
}
return root;
}
void push(struct tnode **h,struct node *r){
struct tnode *nn=(struct tnode*)malloc(sizeof(struct tnode));
nn->t=r;
nn->next=*h;
*h=nn;
}
struct node *pop(struct tnode **h){
struct tnode *curr=*h;
struct tnode *res=curr->t;
*h=curr->next;
return res;
}
void preOrder(struct node *root){
struct node *curr=root;
struct tnode *stack=NULL;
while(curr!=NULL||stack!=NULL){
while(curr!=NULL){
    printf("%d ",curr->data);
    push(&stack,curr);
    curr=curr->left;
}
curr=pop(&stack);
curr=curr->right;
}
}
int main(){
int t;
int data;
struct node *root=NULL;
scanf("%d",&t);
while(t--){
    scanf("%d",&data);
    root=insert(root,data);
}
preOrder(root);
return 0;
}
