#include<stdio.h>
#include<stdlib.h>
struct node{
int data;
struct node *left;
struct node *right;
};
struct node* newNode(int data){
struct node *n=(struct node*)malloc(sizeof(struct node));
n->data=data;
n->left=NULL;
n->right=NULL;
return n;
}
struct tnode{
struct tnode *t;
struct node *next;
};
void inOrder(struct node *root){
    if(root==NULL)
        return;
inOrder(root->left);
printf("%d ",root->data);
inOrder(root->right);
}
void push(struct tnode **h,struct node *d){
struct tnode *nn=(struct tnode*)malloc(sizeof(struct tnode));
struct tnode *curr=*h;
nn->t=d;
nn->next=NULL;
    if(*h==NULL){
        *h=nn;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=nn;
    }
}
struct node* pop(struct tnode **h){
struct tnode *curr=*h;
*h=curr->next;
return curr->t;
}

void mirror(struct node *root){
struct node *curr=root,*tmp;
struct tnode *queue=NULL;
push(&queue,curr);
while(queue!=NULL){
 curr=pop(&queue);
tmp=curr->left;
curr->left=curr->right;
curr->right=tmp;
if(curr->left){
    push(&queue,curr->left);
}
if(curr->right){
    push(&queue,curr->right);
}
}
}
int main(){
struct node *root = newNode(1);
  root->left        = newNode(2);
  root->right       = newNode(3);
  root->left->right  = newNode(4);
  root->right->right = newNode(5);
  inOrder(root);
mirror(root);
printf("\n");
inOrder(root);
}

