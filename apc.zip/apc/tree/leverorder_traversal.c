
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

struct node {

    int data;
    struct node *left;
    struct node *right;

};
struct tnode{
struct node *t;
struct tnode *next;
};
struct node* insert( struct node* root, int d ) {

	if(root == NULL) {

        struct node* node = (struct node*)malloc(sizeof(struct node));

        node->data = d;

        node->left = NULL;
        node->right = NULL;
        return node;

	}
	else if(d<=root->data){
    root->left=insert(root->left,d);
}
else if(d>root->data){
    root->right=insert(root->right,d);
}
return root;
}
void push(struct tnode **h,struct node *d){
struct tnode *nn=(struct tnode*)malloc(sizeof(struct tnode));
struct tnode *curr=*h;
nn->t=d;
nn->next=NULL;
    if(*h==NULL){
        *h=nn;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=nn;
    }
}
struct node* pop(struct tnode **h){
struct tnode *curr=*h;
*h=curr->next;
return curr->t;
}
void levelOrder(struct node *r){
struct node *curr=r;
struct tnode *stack=NULL;
push(&stack,curr);
while(curr!=NULL||stack!=NULL){
    curr=pop(&stack);
    printf("%d ",curr->data);
    if(curr->left!=NULL){
        push(&stack,curr->left);
    }
    if(curr->right!=NULL){
        push(&stack,curr->right);
    }
    curr=NULL;
}
}
/*struct node* newNode(int data)
{
    struct node* node = (struct node*)
                        malloc(sizeof(struct node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;

    return(node);
}*/
int main() {

    struct node* root = NULL;

    int t;
    int data;

    scanf("%d", &t);

    while(t-- > 0) {
        scanf("%d", &data);
        root = insert(root, data);
    }
    /*struct node *root = newNode(1);
    root->left        = newNode(2);
    root->right       = newNode(3);
    root->left->left  = newNode(4);
    root->left->right = newNode(5);*/

	levelOrder(root);
    return 0;
}
