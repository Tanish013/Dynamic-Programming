#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

struct node {

    int data;
    struct node *left;
    struct node *right;

};
struct tnode{
struct node *t;
struct tnode *next;
};
struct node* insert( struct node* root, int d ) {

	if(root == NULL) {

        struct node* node = (struct node*)malloc(sizeof(struct node));

        node->data = d;

        node->left = NULL;
        node->right = NULL;
        return node;

	}
	else if(d<=root->data){
    root->left=insert(root->left,d);
}
else if(d>root->data){
    root->right=insert(root->right,d);
}
return root;
}
void push(struct tnode **h,struct node *d){
struct tnode *nn=(struct tnode*)malloc(sizeof(struct tnode));
nn->t=d;
nn->next=*h;
*h=nn;
}
struct node* pop(struct tnode **h){
struct tnode *curr=*h;
*h=curr->next;
return curr->t;
}
void inOrder(struct node *r){
struct node *curr=r;
struct tnode *stack=NULL;
while(curr!=NULL||stack!=NULL){
    while(curr!=NULL){
        push(&stack,curr);
    curr=curr->left;
    }
    curr=pop(&stack);
    printf("%d ",curr->data);
    curr=curr->right;
}
}
int main() {

    struct node* root = NULL;

    int t;
    int data;

    scanf("%d", &t);

    while(t-- > 0) {
        scanf("%d", &data);
        root = insert(root, data);
    }

	inOrder(root);
    return 0;
}
