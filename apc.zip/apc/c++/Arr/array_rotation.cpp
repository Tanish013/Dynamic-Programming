#include<iostream>
using namespace std;
int main(){
int n;
cout<<"Enter no of iterations ";
cin>>n;
cout<<"Size of array ";
int si;
cin>>si;
int a[si];
cout<<"Array elements ";
for(int i=0;i<si;i++)
cin>>a[i];
for(int i=0;i<n%si;i++){
    int t=a[si-1];
    for(int j=si-1;j>0;j--){
        a[j]=a[j-1];
    }
    a[0]=t;
}
for(int i=0;i<si;i++)
cout<<a[i]<<endl;

}
