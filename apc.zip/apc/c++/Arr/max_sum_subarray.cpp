#include<iostream>
using namespace std;
int main(){
int n,sum=0,max_sum=INT_MIN;
//cin>>n;
int a[9]={-2,1,-3,4,-1,2,1,-5,4};
//for(int i=0;i<n;i++)
  //  cin>>a[i];
for(int i=0;i<9;i++){
    sum+=a[i];
    if(sum>max_sum){
        max_sum=sum;
    }
    if(sum<0)
        sum=0;
}
cout<<max_sum;
}

