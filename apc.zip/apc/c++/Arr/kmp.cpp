#include<iostream>
#include<string.h>
using namespace std;
void comp(char *a,int l,int *lps){
int i=0;
lps[0]=0;
for(int j=1;j<l;){
    if(a[i]==a[j]){
        lps[j]=i+1;
        i++;
        j++;
    }
    else{
        if(i==0){
            lps[j]=0;
            j++;
        }
        else{
            i=lps[i-1];
        }
    }
}
for(i=0;i<l-1;i++)
cout<<lps[i]<<" ";
cout<<lps[i]<<endl;
}
void Search(char *a,char *b){
int l=strlen(b);
int l1=strlen(a);
int lps[l];
comp(b,l,lps);
int i,j=0,res=-1;
for(i=0;i<l1;){
    if(b[j]==a[i]){
        i++;
        j++;
    }
    if(j==l){
        res=i-j;
        cout<<res<<endl;
        j=lps[j-1];
    }
    else if(b[j]!=a[i]&&i<l1){
        if(j==0)
            i=i+1;
        else{
            j=lps[j-1];
        }
    }
}
}
int main(){
char txt[] = "AABAACAADAABAABA";
    char pat[] = "AABA";
Search(txt,pat);
}
