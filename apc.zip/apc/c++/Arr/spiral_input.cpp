#include<iostream>
using namespace std;
int main(){
int n;
cout<<"Enter Size ";
cin>>n;
int ar[n][n]={0},a=0,b=n-1,c=n-1,d=0,co=0,m=n;
while(a<=c && d<=b)
{
for(int i=d;i<m;i++)
    ar[a][i]=++co;
a++;
for(int j=a;j<m;j++)
    ar[j][b]=++co;
b--;
for(int k=b;k>=d;k--)
    ar[c][k]=++co;
c--;
for(int l=c;l>=a;l--)
    ar[l][d]=++co;
d++;
m--;
}
for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
        cout<<ar[i][j]<<" ";
    }
    cout<<endl;
}
}
