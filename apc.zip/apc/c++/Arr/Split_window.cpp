#include<iostream>
using namespace std;
int main(){
int a[7]={1,1,0,1,1,0,0};
int c_zero=-1,p_zero=-1,p_p_zero=-1,d=0,ma=0;
for(int i;i<n;i++){
    c_zero=i;
    if(c_zero-p_p_zero>ma){
        ma=c_zero-p_p_zero;
        d=p_zero;
    }
    if(a[i]==0&&p_p_zero<0&&p_zero<0){
        p_zero=i;
    }
    else if(a[i]==0&&p_zero>0&&p_p_zero<0){
        p_p_zero=p_zero;
        p_zero=i;
    }
    else if(a[i]==0&&p_zero>0 && p_p_zero>0){
        if((c_zero-p_p_zero>d){
           d=c_zero-p_p_zero;
           ma=d;
           }
    }
}




}
