#include <iostream>
#include<cstring>
#define int board[10][10]
using namespace std;
int n;
bool safe(int row,int col){
    int i,j;
    for(i=0;i<col;i++){
        if(board[row][i])
        return false;
    }
    for(i=row,j=col;i>=0&&j>=0;i--,j--)
    {
        if(board[i][j])
        return false;
    }
    for (i=row, j=col; j>=0 && i<n; i++, j--)
        if (board[i][j])
            return false;
    return true;
}
void print(){
    cout<<"[";
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(board[i][j]==1)
            cout<<j+1<<" ";
        }
    }
    cout<<"] ";
}
bool solveNUtil(int col){
    if(col==n){
    print();
    return true;
    }
    int res=false;
    for(int i=0;i<n;i++){
        if(safe(i,col)){
            board[i][col]=1;
            res=solveNUtil(col+1)||res;
            board[i][col]=0;
        }
    }
    return false;
}
void solve(){
    // int board[n][n];
    // memset(board,0,sizeof(board));
    if(solveNUtil(0)==false){
     cout<<-1<<endl;
     return ;
    }
    return ;
}
int main() {
	int t;
	cin>>t;
	while(t--){
	    cin>>n;
	    if(n==1)
	    cout<<"[1 ]"<<endl;
	    else if(n==2||n==3)
	    cout<<-1<<endl;
	    else
	    solve();
	}
	return 0;
}
