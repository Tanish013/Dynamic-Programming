#include<bits/stdc++.h>
using namespace std;
int main(){
int A[4]={5,8,10,15},B[5]={6,9,15,78,89},C[7]={2,3,6,6,8,8,10};
int i=0,j=0,k=0,diff=INT_MAX,flag=0;
while(i<4&&j<5&&k<7){
if((A[i]<B[j])&&(A[i]<C[k])&&((max(B[j],C[k]))-A[i]<diff)){
    diff=max(B[j],C[k])-A[i];
    i++;
}
else if((B[j]<A[i])&&(B[j]<C[k])&&((max(A[i],C[k]))-B[j]<diff)){
    diff=max(A[i],C[k])-B[j];
    j++;
}
else if((C[k]<B[j])&&(C[k]<A[i])&&(((max(B[j],A[i]))-C[k])<diff)){
    diff=max(A[i],B[j])-C[k];
    k++;
}
else if(A[i]==B[j]&&A[i]==C[k]){
    cout<<0;
    flag=1;
    break;
}
else{
if((A[i]<=B[j])&&(A[i]<=C[k])){
    i++;}
else if((B[j]<A[i])&&(B[j]<=C[k])){
    j++;}
else if((C[k]<B[j])&&(C[k]<A[i])){
    k++;}
}
}
if(flag==0)
cout<<diff;
}
