#include<iostream>
#include<bits/stdc++.h>
#include<vector>
using namespace std;
int main(){
int k=1,x=0,y=0;
int a1[]={1,2,3};
int a2[]={2,3,4};
vector<pair<int,int> > v;
for(int i=0;i<3;i++){
    v.push_back(make_pair(a1[i],1));
    v.push_back(make_pair(a2[i],0));
}
sort(v.begin(),v.end());
for(int i=0;i<v.size();i++){
    if(v[i].second==1){
        x++;
        y=max(x,y);
    }
    else
        x--;
}
//cout<<y<<endl;
cout<<(k>=y);
}
