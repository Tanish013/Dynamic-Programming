 #include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
vector<pair<int,int> >v;
int n;
cin>>n;
int a[n];
for(int i=0;i<n;i++){
cin>>a[i];
v.push_back(make_pair(a[i],i));
}
sort(v.begin(),v.end());
//for(int i=0;i<n;i++){
  //  cout<<v[i].second<<endl;
//}
//cout<<"Ans"<<endl;
int ma=0,mi=v[0].second;
for(int i=0;i<n-1;i++){
    int s=v[i+1].second-mi;
        ma=max(ma,s);
        mi=min(mi,v[i+1].second);
    }
cout<<ma;
return 0;
}
