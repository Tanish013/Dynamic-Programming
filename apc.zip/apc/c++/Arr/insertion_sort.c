#include<stdio.h>
void sor(int *a,int n){
int i,j,key,l;
for(i=1;i<n;i++){
    j=i-1;
    key=a[i];
    while(j>=0&&key<a[j]){
        a[j+1]=a[j];
        j=j-1;
    }
    a[j+1]=key;
}

}
int main(){
int arr[]={5,4,3,2,1};
sor(arr,5);
for(int i=0;i<5;i++){
    printf("%d ",arr[i]);
}
}
