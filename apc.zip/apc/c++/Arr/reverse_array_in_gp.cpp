#include<bits/stdc++.h>
using namespace std;
int main(){
int m=14,n=14,k=5,b=1;
int a[n]={1,2,3,4,5,6,7,8,9,10,11,12,13,14};
for(int i=0;i<n;i+=k){
    if(i+k<=n){
        for(int j=0;j<k/2;j++){
            swap(a[i+j],a[i+k-1-j]);
        }
    }
    else{
        for(int j=i;j<n;j++){
            swap(a[j],a[n-1]);
            n--;
        }
    }
}
for(int i=0;i<m;i++)
    cout<<a[i]<<endl;
}
