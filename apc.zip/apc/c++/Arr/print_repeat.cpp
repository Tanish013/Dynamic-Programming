#include<iostream>
using namespace std;
int main(){
int a=9,b=3;
int ar1[a]={1,2,3,4,5,6,7,8,9},ar2[b]={3,3,5};
int i=0,j=0,k=0;
for(i=0;i<a;i++){
    if(j<b){
        if(ar2[j]==ar1[i]){
            cout<<ar2[j]<<" ";
            j++;
        }
    }
}

}
