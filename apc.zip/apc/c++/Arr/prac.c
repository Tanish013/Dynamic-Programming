#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
struct node{
    int data;
    struct node *next;
};
void pu(struct node **h,int val){
    struct node *n=(struct node *)malloc(sizeof(struct node));
struct node *curr=*h;
n->data=val;
n->next=NULL;
if(*h==NULL){
    *h=n;
}
else{
    while(curr->next!=NULL)
        curr=curr->next;

curr->next=n;
}
}
void merge(struct node *h1,struct node *h2){
struct node *res=NULL;
while(h1!=NULL&&h2!=NULL){
    if(h1->data<=h2->data){
        struct node *temp=h1->next;
        h1->next=res;
        res=h1;
        h1=temp;
    }
    else{
        struct node *temp=h2->next;
        h2->next=res;
        res=h2;
        h2=temp;
    }
}
while(h1!=NULL){
    struct node *temp=h1->next;
        h1->next=res;
        res=h1;
        h1=temp;
}
while(h2!=NULL){
    struct node *temp=h2->next;
        h2->next=res;
        res=h2;
        h2=temp;
}
while(res!=NULL){
printf("%d ",res->data);
res=res->next;
}
}
int main() {
    int n=3;
    //scanf("%d",&n);
  struct node *head1=NULL,*head2=NULL;
  for(int i=0;i<n;i++){
      int x;
      scanf("%d",&x);
      pu(&head1,x);
      //pu(&head2,y);
  }
  for(int i=0;i<n;i++){
      int y;
      scanf("%d",&y);
      pu(&head2,y);
  }
  /*while(head1!=NULL){
printf("%d ",head1->data);
head1=head1->next;
  }*/
  merge(head1,head2);
    return 0;
}

