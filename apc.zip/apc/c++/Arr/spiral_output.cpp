#include<iostream>
using namespace std;
int main(){
int n,m;
cin>>n>>m;
int ar[n][m];
for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    cin>>ar[i][j];
int a=0,d=0,b=n-1,c=n-1;
cout<<"SPIRAL MATRIX"<<endl;
while(a<=c&&d<=b){
    for(int i=d;i<n;i++)
        cout<<ar[a][i]<<endl;
    a++;
    for(int j=a;j<n;j++)
        cout<<ar[j][b]<<endl;
    b--;
    for(int k=b;k>=d;k--)
        cout<<ar[c][k]<<endl;
    c--;
    for(int l=c;l>=a;l--)
        cout<<ar[l][d]<<endl;
    d++;
    n--;
}
}
