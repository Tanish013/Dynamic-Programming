#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
cout<<"Enter array size";
int n;
cin>>n;
int ar1[n],ar2[n];
cout<<"Enter first array elements ";
for(int i=0;i<n;i++)
    cin>>ar1[i];
cout<<"Enter second array elements ";
for(int i=0;i<n;i++)
    cin>>ar2[i];
vector<pair<int,int> >v;
for(int i=0;i<4;i++)
    v.push_back(make_pair(ar1[i],ar2[i]));
sort(v.begin(),v.end());
int n1=v.size();
for(int i=0;i<n1-1;i++){
    if(v[i].second>=v[i+1].first){
        if(v[i+1].second>v[i].second)
            v[i].second=v[i+1].second;
        v.erase(v.begin()+i+1);
        //v.size()=v.size()-1;
        n1--;
        i--;
    }
}
for(int i=0;i<v.size();i++)
    cout<<v[i].first<<" "<<v[i].second<<endl;
}
