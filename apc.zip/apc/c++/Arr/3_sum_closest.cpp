#include<bits/stdc++.h>
using namespace std;
int main(){
int n;
cout<<"Enter Array size";
cin>>n;
int ar[n],target;
cout<<"enter array elements";
for(int i=0;i<n;i++)
    cin>>ar[i];
cout<<"Enter target value";
cin>>target;
sort(ar,ar+n);
int i=0,j,k,temp;
int res=ar[0]+ar[1]+ar[2];
for(i=0;i<n-2;i++){
    j=i+1;
    k=n-1;
    while(j<k){
     temp=ar[i]+ar[j]+ar[k];
     if(abs(target-temp)<abs(target-res)){
        res=temp;
     }
     else if(temp<target)
            j++;
     else
        k--;
    }
}
cout<<"Closest sum to target is "<<res<<" and it is "<<abs(target-res)<<" distance away";

}
