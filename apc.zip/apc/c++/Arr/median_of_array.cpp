#include<stdio.h>
int main(){
    int n,m;
    cin>>n>>m;
int A[n],B[m];
for(int i=0;i<n;i++)
    cin>>A[i];
for(int i=0;i<m;i++)
    cin>>B[i];
int i,j;
i=n/2;
j=(i+((n+m)/2))/2;
while(i<=3&&j<=2){
    if((A[i]<B[j+1])&&A[j]<B[i+1]){
        if((2+3)%2!=0){
            cout<<((A[i]>B[j])?A[i]:B[j]);
        }
        else{
            int c=((A[i]>B[j])?A[i]:B[j]+(A[i]<B[j])?A[i]:B[j])/2;
            cout<<c;
        }
    }
    else if(A[i]>B[j+1]&&A[i+1]<B[j]){
        i++;j--;}
    else if(A[i]<B[j+1]&&A[i+1]>B[j]){
        i++;j--;}
}
}
