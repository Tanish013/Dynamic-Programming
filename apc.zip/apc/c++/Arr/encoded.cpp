#include<iostream>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
using namespace std;
void encoded(char *str){
char *s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/0123456789";
int len=strlen(str);
char *res=(char*)malloc(sizeof(char)*(len/3)*4+5);
int index=0;
for(int i=0;i<len-(len%3);i=i+3){
    res[index++]=s[(str[i]&0xFC)>>2];
    res[index++]=s[(str[i]&0x03)<<4|(str[i+1]&0xF0)>>4];
    res[index++]=s[(str[i+1]&0x0F)<<2|(str[i+2]&0xC0)>>6];
    res[index++]=s[(str[i+2]&0x3F)];
}
for(int i=0;i<index;i++)
    cout<<res[i];
//return res;
}
int main(){
char str[50];
gets(str);
encoded(str);
}
