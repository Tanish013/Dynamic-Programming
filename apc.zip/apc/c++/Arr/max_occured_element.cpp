#include<bits/stdc++.h>
using namespace std;
int main(){
int L[]={2,1,3};
int R[]={5,3,9};
int* n=max_element(R,R+3);
int a[*n+1]={0};
    for(int i=0;i<3;i++){
        a[L[i]]=1;
        a[R[i]+1]=-1;
    }

int c=a[0],m;
for(int i=1;i<*n;i++){
        a[i]+=a[i-1];
    if(c<a[i]){
        c=a[i];
        m=i;
    }
}
cout<<m;
}
