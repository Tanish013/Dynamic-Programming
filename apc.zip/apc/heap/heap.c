#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int n;
int heap[1000],heapsize=0;
void insert(int a){
    heapsize++;
heap[heapsize]=a;
int now=heapsize;
while(a>heap[(now/2)]&&now>0){
    heap[now]=heap[now/2];
    now/=2;
}
heap[now]=a;

}
int main(){
scanf("%d",&n);
//printf("%d",n);
//heap[0]=INT_MAX;
for(int i=0;i<n;i++){
        int a;
    scanf("%d",&a);
insert(a);
}
for(int i=1;i<=n;i++)
    printf("%d ",heap[i]);
}
