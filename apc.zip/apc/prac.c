/*#include<stdio.h>
#include<stdlib.h>
int main(){
int t;
scanf("%d",&t);
for(int z=0;z<t;z++){
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
        int m=n+1;
    int **table=(int**)calloc(m,sizeof(int*));
    for(int i=0;i<=n;i++)
        table[i]=(int*)calloc(m,sizeof(int));
        int count=1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<i;j++){
            if(a[j-1]%a[i-1]==0){
                table[i][j]=1+table[i][j-1];
                if(table[i][j]>count){
                count=table[i][j];
            }
            }
            else{
                table[i][j]=table[i][j-1];
            }
        }
    }
    for(int i=0;i<=n;i++){
        for(int j=0;j<=n;j++){
            printf("%d ",table[i][j]);
        }
        printf("\n");
    }
    printf("%d\n",count);
}
}
*/




/*#include<stdio.h>
#include<stdlib.h>
struct node {

    int data;
    struct node *left;
    struct node *right;

};
struct node* insert( struct node* root, int d ) {

	if(root == NULL) {

        struct node* node = (struct node*)malloc(sizeof(struct node));

        node->data = d;

        node->left = NULL;
        node->right = NULL;
        return node;

	}
	else if(d<=root->data){
    root->left=insert(root->left,d);
}
else if(d>root->data){
    root->right=insert(root->right,d);
}
return root;
}
void preOrder(struct node *root){
    if(root==NULL)
        return ;
    printf("%d ",root->data);
preOrder(root->left);
preOrder(root->right);
}
int main(){
 struct node* root = NULL;

    int t;
    int data;

    scanf("%d", &t);

    while(t-- > 0) {
        scanf("%d", &data);
        root = insert(root, data);
    }

	preOrder(root);
    return 0;
}*/










#include<stdio.h>
#include<string.h>
void Lps(char *a,int n,int *lps){
int i=0;
lps[0]=0;
for(int j=1;j<n;){
    if(a[i]==a[j]){
        lps[j]=i+1;
        i++;j++;
    }
    else{
        if(i==0){
            lps[j]=0;
            j++;
        }
        else
            i=lps[i-1];
    }
}
/*for(int j=0;j<n;j++)
    printf("%d ",lps[j]);*/
}
void Search(char *a,char *b){
int l=strlen(a);
int l1=strlen(b);
int lps[l1];
Lps(b,l1,lps);
int i=0;
int j=0;
while(i<l){
    if(a[i]==b[j]){
        i++;
        j++;
    }
    if(j==l1){
        printf("Found at index %d\n",i-j);
        j=lps[j-1];
    }
    else if(i<l&&a[i]!=b[j]){
            if(j!=0){
            j=lps[j-1];
            }
            else{
                i=i+1;
            }
    }
}
}
int main(){
char txt[] = "AABAACAADAABAABA";
    char pat[] = "AABA";
Search(txt,pat);
}
