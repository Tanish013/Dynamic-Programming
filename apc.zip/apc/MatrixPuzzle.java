package com.uca.util;

public class MatrixPuzzle {

	public static void main(String[] args) {
		int N = 3;
		int M = 3;
		int k = 2;

		char[][] input = new char[N][M];

		input[0][0] = '*';
		input[0][1] = '.';
		input[0][2] = '*';
		input[1][0] = '*';
		input[1][1] = '*';
		input[1][2] = '.';
		input[2][0] = '*';
		input[2][1] = '.';
		input[2][2] = '.';

		System.out.println("max stars in " + k + "X" + k + " box is " + solve(input, N, M, k));

	}

	private static int solve(char[][] input, int inputRows, int inputCols, int k) {
		int boxRows = inputRows - k + 1;
		int boxCols = inputCols - k + 1;
		int[][] box = new int[boxRows][boxCols];
		for (int i = 0; i < inputRows; i++)
			for (int j = 0; j < inputCols; j++)
				if (input[i][j] == '*')
					updateBox(box, i, j, boxRows, boxCols, k);
		int max = 0;
		for (int i = 0; i < boxRows; i++)
			for (int j = 0; j < boxCols; j++)
				if (box[i][j] > max)
					max = box[i][j];
		return max;
	}

	private static void updateBox(int[][] box, int inputRows, int inputCols, int boxRows, int boxCols, int k) {
		int n = inputRows - k + 1;
		int m = inputCols - k + 1;
		System.out.println("row=" + inputRows + " col=" + inputCols + " maxrow=" + boxRows + " maxCol=" + boxCols);
		for (int i = Math.max(0, n); i < Math.min(n + k, boxRows); i++)
			for (int j = Math.max(0, m); j < Math.min(m + k, boxCols); j++)
				box[i][j]++;
	}

}
